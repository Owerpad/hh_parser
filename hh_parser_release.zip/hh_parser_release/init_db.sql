CREATE DATABASE IF NOT EXISTS hh_parser;
USE hh_parser;

CREATE TABLE IF NOT EXISTS vacancies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    company VARCHAR(255),
    skills TEXT,
    description TEXT,
    employment VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO vacancies (title, company, skills, description, employment) VALUES
('Software Engineer', 'Tech Corp', 'Python, SQL, JavaScript', 'Looking for a skilled software engineer...', 'Full-time'),
('Data Analyst', 'Data Solutions', 'SQL, Excel, Python', 'Seeking a data analyst with strong SQL skills...', 'Part-time');