import requests

HH_API_URL = "https://api.hh.ru/vacancies"

def get_vacancies(query, page=0, per_page=10):
    params = {
        "text": query,
        "page": page,
        "per_page": per_page
    }
    response = requests.get(HH_API_URL, params=params)
    if response.status_code == 200:
        return response.json()
    return None