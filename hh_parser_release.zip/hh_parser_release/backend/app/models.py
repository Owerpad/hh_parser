from . import db

class Vacancy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255))
    company = db.Column(db.String(255))
    skills = db.Column(db.Text)
    description = db.Column(db.Text)
    employment = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'company': self.company,
            'skills': self.skills,
            'description': self.description,
            'employment': self.employment,
            'created_at': self.created_at.isoformat()
        }