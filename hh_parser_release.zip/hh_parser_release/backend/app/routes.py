# backend/app/routes.py
from flask import Blueprint, request, jsonify
import pandas as pd
import requests

bp = Blueprint('main', __name__)

# Создаем глобальный датафрейм для хранения данных
vacancies_df = pd.DataFrame(columns=['id', 'title', 'company', 'skills', 'description', 'employment', 'created_at'])

@bp.route('/api/vacancies', methods=['GET'])
def get_vacancies():
    global vacancies_df

    query = request.args.get('query', '')
    sort_by = request.args.get('sort_by', 'created_at')
    order = request.args.get('order', 'desc')

    # Получаем данные с HH.ru
    response = requests.get(f'https://api.hh.ru/vacancies?text={query}&page=0&per_page=100')
    data = response.json()

    # Обрабатываем данные и добавляем их в датафрейм
    new_vacancies = []
    for item in data.get('items', []):
        vacancy = {
            'id': item.get('id'),
            'title': item.get('name', 'No title'),
            'company': item.get('employer', {}).get('name', 'No company'),
            'skills': ', '.join([skill['name'] for skill in item.get('key_skills', [])]) if item.get('key_skills') else 'No skills listed',
            'description': item.get('snippet', {}).get('responsibility', 'No description available'),
            'employment': item.get('employment', {}).get('name', 'No employment type'),
            'created_at': item.get('published_at', 'No date')
        }
        new_vacancies.append(vacancy)

    # Объединяем новые данные с существующим датафреймом
    vacancies_df.drop(vacancies_df.index, inplace=True)
    new_df = pd.DataFrame(new_vacancies)
    vacancies_df = pd.concat([vacancies_df, new_df], ignore_index=True)

    # Сортируем датафрейм
    if sort_by == 'title':
        vacancies_df = vacancies_df.sort_values(by='title', ascending=(order == 'asc'))
    elif sort_by == 'company':
        vacancies_df = vacancies_df.sort_values(by='company', ascending=(order == 'asc'))
    else:
        vacancies_df = vacancies_df.sort_values(by='created_at', ascending=(order == 'asc'))

    # Преобразуем датафрейм в JSON
    vacancies_json = vacancies_df.to_json(orient='records')

    return vacancies_json

def init_routes(app):
    app.register_blueprint(bp)