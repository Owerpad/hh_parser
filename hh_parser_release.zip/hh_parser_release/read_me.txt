docker-compose down
docker-compose up --build

docker logs hh_parser_release-backend-1

hh_parser/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── models.py
│   │   ├── routes.py
│   │   └── utils.py
│   ├── Dockerfile
│   ├── requirements.txt
│   └── wsgi.py
├── frontend/
│   ├── Dockerfile
│   ├── index.html
│   └── static/
│       └── styles.css
├── .env
├── init_db.sql
└── docker-compose.yml